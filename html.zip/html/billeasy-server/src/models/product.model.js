// REPLACE: avoid defining the model twice; re-export the canonical Product
const Product = require('./Product');
module.exports = Product;